export class user {
    email!: string;
    static passwd: any;
    static email: any;
  }
  