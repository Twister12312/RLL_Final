export class Employee {
    eid?: number;
    name?:string;
    dob?:String;
    email?:string;
    designation?:string;
    address?:string;
    gender?:string;
    phone?:number;
    passwd?:string;
}